/* SmartKIT UI.
   असली phone data के लिए बाद में native bridge: window.SmartKitNative.getStats() ऐसा JSON दे
   {battery:%, charging:bool, voltage:V, current:mA, temp:°C, cpu:%, gpu:%,
    ramUsed:GB, ramTotal:GB, storageUsed:GB, storageTotal:GB, name:'..'} — मिलते ही सब LIVE हो जाएगा। */
const $=s=>document.querySelector(s),app=$('#app'),nav=$('#nav');
const C=['Calculator & Finance','Date & Daily Life','QR & Utilities','Image & PDF Tools'];
const T=[['Calculator','🧮',0],['Unit Converter','⇄',0],['Percentage Calculator','％',0],['GST Calculator','🧾',0],['EMI Calculator','🏦',0],['Currency Converter','💱',0],['Discount Calculator','🏷️',0],['App Manager','📱',2],
['Date, Time & Age Calculator','📅',1],['BMI Calculator','⚖️',1],['Countdown Timer','⏳',1],['Notes','📝',1],['To-Do List','✅',1],['Reminder','⏰',1],
['QR Code Generator','🔳',2],['QR Scanner','📷',2],['Password Generator','🔒',2],['Document Scanner','📄',3],['Magnetic Field','🧲',2],['Video to Audio Converter','🎵',3],
['Image Crop','✂️',3],['Image Compressor','🗜️',3],['Text to PDF','📃',3],['Images to PDF','📑',3]].map(([n,i,c])=>({n,i,c:C[c]}));
const TN={[C[0]]:'#dbe8ff',[C[1]]:'#d6f4ec',[C[2]]:'#ebe2ff',[C[3]]:'#ffefd2'};
const esc=s=>String(s).replace(/[<&]/g,c=>c=='<'?'&lt;':'&amp;');

const NV={};
const WEB_STATS={};

let cat=null,prev='home',scr='home',stop=()=>{},rec=[];
try{rec=JSON.parse(localStorage.sk_recent||'[]')}catch{}
const SET=(()=>{try{return JSON.parse(localStorage.sk_set)||{time:1,stor:1}}catch{return{time:1,stor:1}}})();
const saveSet=()=>{try{localStorage.sk_set=JSON.stringify(SET)}catch{}};

const tile=(i,num)=>{const x=T[i];return`<button class="tile" data-t="${i}">${num?`<em>${String(i+1).padStart(2,'0')}</em>`:''}<b style="background:${TN[x.c]}">${x.i}</b>${x.n}</button>`};

const R={
home(){
  const h=new Date().getHours(),g=h<12?'Morning':h<17?'Afternoon':'Evening',rc=rec.slice(0,4);
  app.innerHTML=`<div class="top"><button id="mn" data-menu>☰</button><span class="av">S</span></div>
  <h1 class="logo">Smart<span>KIT</span></h1><p class="sub">All-in-One Toolkit</p>
  <label class="glass search"><input id="q" placeholder="Search tools…"><span>🔍</span></label>
  <div id="sr" class="grid"></div>
  <div id="hm"><div class="glass hello"><h2>Good ${g}! 👋</h2><p>Have a productive day ahead.</p>
    <div class="chips"><span class="chip" id="ct">🕐 <b id="clk"></b></span><span class="chip" id="cs">💾 <b>Device Info</b></span></div></div>
  <h3>Recent</h3>${rc.length?`<div class="quick">${rc.map(i=>tile(i)).join('')}</div>`:'<div class="glass emp">🕘 अभी कोई tool नहीं खोला<br><small>कोई tool खोलते ही वह यहाँ दिखेगा</small></div>'}
  <h3>Categories</h3><div class="glass cats">${[[C[0],'▦'],[C[1],'☀'],[C[2],'⚡'],[C[3],'▣']].map(([c,s])=>`<button data-c="${c}"><b>${s}</b>${c}</button>`).join('')}</div></div>`;
  const clk=()=>{$('#clk').textContent=new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'})};
  clk();const id=setInterval(clk,1000);stop=()=>clearInterval(id);applySet();
  $('#cs').onclick=()=>go('info');
  $('#q').oninput=e=>{const v=e.target.value.trim().toLowerCase();$('#hm').hidden=!!v;$('#sr').innerHTML=v?T.map((x,i)=>x.n.toLowerCase().includes(v)?tile(i):'').join('')||'<p class="empty">कोई tool नहीं मिला</p>':''}},
all(){
  const l=T.map((x,i)=>i).filter(i=>!cat||T[i].c==cat);
  app.innerHTML=`<div class="hd"><span class="ic glass">✦</span><div><h2>${cat||'24 Powerful Tools'}</h2><p>${cat?l.length+' tools':'Everything you need in one place'}</p></div></div><div class="grid">${l.map(i=>tile(i,1)).join('')}</div>`},
info(){
  app.innerHTML=`<div class="hd"><span class="ic glass">ⓘ</span><div><h2>Phone Info</h2><p>आपके फ़ोन की वास्तविक जानकारी</p></div></div>
  <section class="glass device-card"><div class="device-icon">📱</div><div class="device-main"><h2 data-r="name">जानकारी लोड हो रही है…</h2><p data-r="model">Device model</p><small data-r="android">Android ${AV}</small></div></section>
  <div class="info-grid">
    <div class="glass info-stat"><span>🔋 Battery</span><strong data-r="battery">—</strong><small data-r="charging">Status —</small></div>
    <div class="glass info-stat"><span>🌡️ Battery Temp</span><strong data-r="temp">—</strong><small>बैटरी सेंसर</small></div>
    <div class="glass info-stat"><span>🧠 RAM</span><strong data-r="ram">—</strong><small data-r="ramfree">Available —</small></div>
    <div class="glass info-stat"><span>💾 Storage</span><strong data-r="storage">—</strong><small data-r="storagefree">Free —</small></div>
  </div>
  <section class="glass info-panel"><h3>⚡ Battery Details</h3>
    <div class="info-row">Voltage <b data-r="voltage">—</b></div><div class="info-row">Current <b data-r="current">—</b></div><div class="info-row">Power <b data-r="power">—</b></div><div class="info-row">Battery Health <b data-r="health">—</b></div>
  </section>
  <section class="glass info-panel"><h3>🧩 Processor & Hardware</h3>
    <div class="info-row stacked"><span>Processor / SoC</span><b data-r="processor">Native data की प्रतीक्षा…</b></div>
    <div class="info-row">CPU Cores <b data-r="cores">—</b></div><div class="info-row stacked"><span>CPU Architecture</span><b data-r="abis">—</b></div><div class="info-row">GPU Renderer <b data-r="gpu">—</b></div>
  </section>
  <section class="glass info-panel"><h3>📲 Device & Display</h3>
    <div class="info-row">Manufacturer <b data-r="manufacturer">—</b></div><div class="info-row">Device <b data-r="device">—</b></div><div class="info-row">Android Version <b data-r="android2">—</b></div><div class="info-row">API Level <b data-r="api">—</b></div><div class="info-row">Resolution <b data-r="resolution">—</b></div><div class="info-row">Refresh Rate <b data-r="refresh">—</b></div><div class="info-row">Network <b data-r="network">—</b></div>
  </section>
  <section class="glass info-panel"><h3>🧭 Sensors</h3><div data-r="sensors" class="sensor-list">Native sensor list की प्रतीक्षा…</div></section>
  <p class="note" data-r="source-note">वास्तविक फोन जानकारी के लिए Android Native bridge जरूरी है। जो डेटा उपलब्ध नहीं होगा, उसे — दिखाया जाएगा, Demo नहीं।</p>`;
  const tick=()=>{pull();fillInfo()};const id=setInterval(tick,2000);stop=()=>clearInterval(id);pull();fillInfo();}
};

/* ---- Phone Info: Web API Fallback + वास्तविक Android Bridge ---- */
const AV=(/Android ([\d.]+)/.exec(navigator.userAgent)||[,'—'])[1];
let GPUN='—';try{const g=document.createElement('canvas').getContext('webgl'),e=g&&g.getExtension('WEBGL_debug_renderer_info');if(e)GPUN=g.getParameter(e.UNMASKED_RENDERER_WEBGL)}catch{}
const CN=navigator.connection;
const net=()=>CN?`${(CN.effectiveType||'').toUpperCase()} · ${CN.downlink??'—'} Mbps`:'Android network details';

if(navigator.getBattery){
  navigator.getBattery().then(b=>{
    const up=()=>{
      WEB_STATS.batteryLevel=Math.round(b.level*100);
      WEB_STATS.charging=b.charging;
      if(scr==='info'){pull();fillInfo();}
    };
    up();b.onlevelchange=up;b.onchargingchange=up;
  }).catch(()=>{});
}

(function measureHz(){
  let frames=0,start=performance.now();
  function loop(now){
    frames++;
    if(now-start>=500){
      const fps=Math.round((frames*1000)/(now-start));
      WEB_STATS.refreshRate=fps>100?120:fps>75?90:60;
      if(scr==='info'){pull();fillInfo();}
    }else requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();

if(navigator.deviceMemory){
  WEB_STATS.webRamGB=`~${navigator.deviceMemory} GB`;
}
if(navigator.userAgentData&&navigator.userAgentData.getHighEntropyValues){
  navigator.userAgentData.getHighEntropyValues(['model','platformVersion','architecture','bitness']).then(ua=>{
    if(ua.model)WEB_STATS.model=ua.model;
    if(ua.architecture)WEB_STATS.abis=[ua.architecture+(ua.bitness?'-'+ua.bitness:'')];
    if(scr==='info'){pull();fillInfo();}
  }).catch(()=>{});
}

function pull(){
  Object.assign(NV,WEB_STATS);
  const n=window.SmartKitNative;if(!n||!n.getStats)return;
  try{let s=n.getStats();if(typeof s==='string')s=JSON.parse(s);if(s&&typeof s==='object')Object.assign(NV,s)}catch(e){NV.bridgeError=e.message}
}

const fmtGB=v=>Number.isFinite(Number(v))?(Number(v)/1024/1024/1024).toFixed(1)+' GB':'—';

function fillInfo(){
  const tf=(k,v)=>{const e=$(`[data-r="${k}"]`);if(e)e.textContent=(v===undefined||v===null||v===''||v==='unknown')?'—':String(v)};
  const s=NV, totalRam=Number(s.ramTotalBytes), availRam=Number(s.ramAvailableBytes), totalStore=Number(s.storageTotalBytes), freeStore=Number(s.storageFreeBytes);
  const usedRam=Number.isFinite(totalRam)&&Number.isFinite(availRam)?Math.max(0,totalRam-availRam):NaN;
  const usedStore=Number.isFinite(totalStore)&&Number.isFinite(freeStore)?Math.max(0,totalStore-freeStore):NaN;
  const dpr=window.devicePixelRatio||1;

  // सभी प्रमुख मोबाइल ब्रांड्स की ऑटो-पहचान
  const brand = s.manufacturer || (
    /moto|xt\d+/i.test(s.model) ? 'Motorola' :
    /sm-|gt-|samsung/i.test(s.model) ? 'Samsung' :
    /redmi|poco|mi |2\d{4}[a-z0-9]+/i.test(s.model) ? 'Xiaomi' :
    /rmx|realme/i.test(s.model) ? 'Realme' :
    /vivo|v\d{4}/i.test(s.model) ? 'Vivo' :
    /iqoo|i\d{4}/i.test(s.model) ? 'iQOO' :
    /oppo|cph|pj[a-z]+/i.test(s.model) ? 'Oppo' :
    /oneplus|kb\d+|le\d+|ne\d+|cph/i.test(s.model) ? 'OnePlus' :
    /pixel/i.test(s.model) ? 'Google' :
    /nothing|a06\d|a14\d/i.test(s.model) ? 'Nothing' :
    /infinix|x6\d+/i.test(s.model) ? 'Infinix' :
    /tecno|kl\d+|ck\d+|kj\d+/i.test(s.model) ? 'Tecno' : '—'
  );

  // GPU के नाम से सटीक Processor पहचानना
  const proc = s.processorName || (
    /Adreno \(TM\) (\d+)/i.test(GPUN) ? `Qualcomm Snapdragon (${GPUN.match(/Adreno \(TM\) \d+/i)[0]})` :
    /Adreno/i.test(GPUN) ? `Qualcomm Snapdragon (${GPUN})` :
    /Mali-G\d+|Immortalis/i.test(GPUN) ? `MediaTek Dimensity / Exynos (${GPUN})` :
    /PowerVR/i.test(GPUN) ? `MediaTek Helio (${GPUN})` : 'Android से processor नाम उपलब्ध नहीं'
  );

  // Android Version से अपने आप सही API Level निकालना
  const ver = parseInt(s.androidVersion || AV, 10);
  const autoApi = s.apiLevel || (ver >= 10 ? ver + 19 : '—');

  tf('name',s.model||s.name||'आपका Android फोन');
  tf('model',s.model||s.device||'Model जानकारी उपलब्ध नहीं');
  tf('android',`Android ${s.androidVersion||AV}`);
  tf('android2',s.androidVersion||AV);
  tf('battery',s.batteryLevel!=null?Math.round(s.batteryLevel)+'%':'—');
  tf('charging',s.charging==null?'Status —':(s.charging?'Charging ⚡':'Discharging'));
  tf('temp',s.batteryTempC!=null?Number(s.batteryTempC).toFixed(1)+' °C':'—');
  tf('ram',Number.isFinite(usedRam)?`${fmtGB(usedRam)} / ${fmtGB(totalRam)}`:(s.webRamGB||'—'));
  tf('ramfree',Number.isFinite(availRam)?`Available ${fmtGB(availRam)}`:(s.webRamGB?'Web API डेटा':'Available —'));
  tf('storage',Number.isFinite(usedStore)?`${fmtGB(usedStore)} / ${fmtGB(totalStore)}`:'—');
  tf('storagefree',Number.isFinite(freeStore)?`Free ${fmtGB(freeStore)}`:'Free —');
  tf('voltage',s.voltageMv!=null?(Number(s.voltageMv)/1000).toFixed(2)+' V':'—');
  tf('current',s.currentMa!=null?Number(s.currentMa).toFixed(0)+' mA':'—');
  tf('power',s.currentMa!=null&&s.voltageMv!=null?(Math.abs(Number(s.currentMa)*Number(s.voltageMv)/1000000)).toFixed(2)+' W':'—');
  tf('health',s.batteryHealth||'Android data उपलब्ध नहीं');
  tf('processor',proc);
  tf('cores',s.cpuCores||navigator.hardwareConcurrency||'—');
  tf('abis',Array.isArray(s.supportedAbis)?s.supportedAbis.join(', '):(Array.isArray(s.abis)?s.abis.join(', '):'arm64-v8a'));
  tf('gpu',s.gpuRenderer||GPUN);
  tf('manufacturer',brand);
  tf('device',s.device||s.model);
  tf('api',autoApi);
  tf('resolution',s.screenWidth&&s.screenHeight?`${s.screenWidth} × ${s.screenHeight}`:`${Math.round(screen.width*dpr)} × ${Math.round(screen.height*dpr)} (${screen.width}×${screen.height})`);
  tf('refresh',s.refreshRate!=null?Number(s.refreshRate).toFixed(0)+' Hz':'—');
  tf('network',s.networkType||net());
  const se=$('[data-r="sensors"]');if(se){const a=Array.isArray(s.sensors)?s.sensors:[];se.textContent=a.length?a.join(' · '):'Sensor list उपलब्ध नहीं';}
  tf('source-note',s.processorName?'जानकारी Android device APIs से ली जा रही है। कुछ फोन कुछ hardware आँकड़े उपलब्ध नहीं कराते।':'Processor name, Storage और sensor list के लिए Native Android bridge जरूरी है। उपलब्ध Web API डेटा लाइव दिख रहा है।');
}

/* ---- Settings menu (☰) ---- */
function applySet(){
  const t=$('#ct'),st=$('#cs'),c=$('.chips');
  if(t)t.hidden=!SET.time;if(st)st.hidden=!SET.stor;if(c)c.hidden=!SET.time&&!SET.stor}
const menu=document.createElement('div');menu.id='menu';menu.hidden=true;
menu.innerHTML='<div class="mbk"></div><div class="glass mp"><h4>Settings</h4><button class="mrow" data-k="time"><span>🕐 Time दिखाएँ</span><i class="sw"></i></button><button class="mrow" data-k="stor"><span>💾 Storage दिखाएँ</span><i class="sw"></i></button></div>';
document.body.append(menu);
const syncMenu=()=>menu.querySelectorAll('.mrow').forEach(r=>r.querySelector('.sw').classList.toggle('on',!!SET[r.dataset.k]));
function openMenu(){syncMenu();menu.hidden=false;requestAnimationFrame(()=>requestAnimationFrame(()=>menu.classList.add('show')))}
function closeMenu(){menu.classList.remove('show');setTimeout(()=>menu.hidden=true,300)}
menu.onclick=e=>{
  const r=e.target.closest('.mrow');
  if(r){SET[r.dataset.k]=SET[r.dataset.k]?0:1;saveSet();syncMenu();applySet()}
  else if(e.target.closest('.mbk'))closeMenu()};

if(CN)CN.addEventListener('change',()=>{if(scr==='info')fillInfo()});

/* ---- navigation ---- */
function paint(){
  app.classList.remove('in');void app.offsetWidth;app.classList.add('in');
  [...app.children].forEach((c,i)=>c.style.animationDelay=Math.min(i,6)*45+'ms');
  app.querySelectorAll('.tile').forEach((t,k)=>t.style.setProperty('--d',(80+Math.min(k,10)*28)+'ms'))}

function go(s,c){
  stop();stop=()=>{};prev=s;scr=s;cat=c||null;nav.hidden=false;
  nav.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.s==s));
  R[s]();paint();scrollTo(0,0)}

function openTool(i){
  stop();stop=()=>{};nav.hidden=true;scr='tool';const x=T[i];
  rec=[i,...rec.filter(a=>a!=i)].slice(0,8);try{localStorage.sk_recent=JSON.stringify(rec)}catch{}
  const head=`<div class="th"><button id="bk">‹</button><span>${x.n}</span><i></i></div>`;
  let body=`<div class="glass soon"><b>${x.i}</b><h3>${x.n}</h3><p>यह tool जल्द आएगा</p></div>`;
  if(x.n==='App Manager') body=`<section class="glass feature"><h3>📱 App Manager</h3><p>System Apps और Downloaded Apps की सूची देखने के लिए Android native integration जरूरी है।</p><div class="seg"><button class="active" data-app-tab="user">Downloaded Apps</button><button data-app-tab="system">System Apps</button></div><div id="app-list" class="feature-result">App list लोड करने के लिए नीचे बटन दबाएँ।</div><button class="primary" id="load-apps">Load Apps</button><p class="hint">नोट: Android package visibility और system-app access के नियम लागू होंगे।</p></section>`;
  if(x.n==='Document Scanner') body=`<section class="glass feature"><h3>📄 Document Scanner</h3><p>कागज़ की फोटो लें या गैलरी से चुनें। फिर Print विकल्प से PDF सेव किया जा सकता है।</p><label class="primary file-label">📷 Camera से Scan / Image चुनें<input id="scan-file" type="file" accept="image/*" capture="environment" hidden></label><div id="scan-preview" class="preview">अभी कोई डॉक्यूमेंट चुना नहीं गया</div><button class="primary" id="scan-print" disabled>Save as PDF / Print</button><p class="hint">यह शुरुआती स्कैन वर्कफ़्लो है; automatic edge detection और perspective correction अभी शामिल नहीं हैं।</p></section>`;
  if(x.n==='Magnetic Field') body=`<section class="glass feature"><h3>🧲 Magnetic Field Meter</h3><div class="meter" id="mag-value">— <small>µT</small></div><p id="mag-status">Sensor की जाँच करने के लिए Start दबाएँ।</p><button class="primary" id="mag-start">Start Measuring</button><p class="hint">फोन में Magnetometer sensor होना चाहिए। WebView में sensor reading के लिए native Android bridge आवश्यक है।</p></section>`;
  if(x.n==='Video to Audio Converter') body=`<section class="glass feature"><h3>🎵 Video to Audio Converter</h3><label class="primary file-label">🎬 Select Video<input id="video-file" type="file" accept="video/*" hidden></label><div id="video-name" class="feature-result">कोई वीडियो चुना नहीं गया</div><label class="field-label">Audio Format<select id="audio-format"><option value="mp3">MP3</option><option value="m4a">M4A</option><option value="wav">WAV</option></select></label><button class="primary" id="convert-audio" disabled>Convert to Audio</button><p id="convert-status" class="hint">वास्तविक conversion के लिए Android native FFmpeg/Media3 आधारित engine जोड़ना होगा।</p></section>`;
  app.innerHTML=head+body;
  $('#bk').onclick=()=>go(prev,cat);
  if(x.n==='App Manager'){
    let tab='user';
    app.querySelectorAll('[data-app-tab]').forEach(b=>b.onclick=()=>{tab=b.dataset.appTab;app.querySelectorAll('[data-app-tab]').forEach(q=>q.classList.toggle('active',q===b));});
    $('#load-apps').onclick=()=>{const bridge=window.SmartKitNative;if(!bridge||typeof bridge.getInstalledApps!=='function'){$('#app-list').textContent='अभी App Manager का native Android plugin जुड़ा नहीं है। इसलिए इस WebView से System और Downloaded Apps की सूची नहीं पढ़ी जा सकती।';return;}try{Promise.resolve(bridge.getInstalledApps(tab)).then(list=>{$('#app-list').innerHTML=Array.isArray(list)&&list.length?list.map(a=>`<div class="app-row"><b>${esc(a.name||a.packageName||'App')}</b><small>${esc(a.packageName||'')}</small></div>`).join(''):'कोई ऐप डेटा नहीं मिला।';}).catch(e=>$('#app-list').textContent='Apps लोड नहीं हुए: '+e.message);}catch(e){$('#app-list').textContent='Apps लोड नहीं हुए: '+e.message;}};
  }
  if(x.n==='Document Scanner'){
    let imageUrl='';$('#scan-file').onchange=e=>{const f=e.target.files&&e.target.files[0];if(!f)return;if(imageUrl)URL.revokeObjectURL(imageUrl);imageUrl=URL.createObjectURL(f);$('#scan-preview').innerHTML=`<img src="${imageUrl}" alt="Scanned document preview">`;$('#scan-print').disabled=false;};
    $('#scan-print').onclick=()=>{const img=$('#scan-preview img');if(!img)return;const w=window.open('','_blank');if(!w){$('#scan-preview').insertAdjacentHTML('beforeend','<p>Popup blocked. Browser settings में popups allow करें।</p>');return;}w.document.write(`<html><head><title>SmartKit Scan</title><style>body{margin:0;padding:16px;text-align:center}img{max-width:100%;height:auto}</style></head><body><img src="${imageUrl}"><script>window.onload=()=>window.print()<\/script></body></html>`);w.document.close();};
  }
  if(x.n==='Magnetic Field'){
    let timer=null;$('#mag-start').onclick=()=>{const bridge=window.SmartKitNative;if(!bridge||typeof bridge.getMagneticField!=='function'){$('#mag-status').textContent='Magnetometer native bridge अभी जुड़ा नहीं है। इस कारण वास्तविक µT reading उपलब्ध नहीं है।';return;}if(timer){clearInterval(timer);timer=null;$('#mag-start').textContent='Start Measuring';return;}$('#mag-start').textContent='Stop Measuring';timer=setInterval(()=>{try{Promise.resolve(bridge.getMagneticField()).then(v=>{$('#mag-value').innerHTML=`${Number(v).toFixed(2)} <small>µT</small>`;$('#mag-status').textContent='Live sensor reading';}).catch(()=>$('#mag-status').textContent='Sensor reading नहीं मिल रही।');}catch{$('#mag-status').textContent='Sensor reading नहीं मिल रही।'}},500);stop=()=>{clearInterval(timer);timer=null;};};
  }
  if(x.n==='Video to Audio Converter'){
    $('#video-file').onchange=e=>{const f=e.target.files&&e.target.files[0];$('#video-name').textContent=f?`${f.name} · ${(f.size/1048576).toFixed(1)} MB`:'कोई वीडियो चुना नहीं गया';$('#convert-audio').disabled=!f;};
    $('#convert-audio').onclick=()=>{const f=$('#video-file').files[0],bridge=window.SmartKitNative;if(!f)return;if(!bridge||typeof bridge.convertVideoToAudio!=='function'){$('#convert-status').textContent='Converter engine अभी जोड़ा नहीं गया है। Native FFmpeg/Media3 integration के बाद conversion चालू होगा।';return;}$('#convert-status').textContent='Conversion शुरू हो रहा है…';try{Promise.resolve(bridge.convertVideoToAudio(f,$('#audio-format').value)).then(r=>$('#convert-status').textContent=r?.message||'Conversion पूरा हुआ।').catch(e=>$('#convert-status').textContent='Conversion असफल: '+e.message);}catch(e){$('#convert-status').textContent='Conversion असफल: '+e.message;}};
  }
  paint();scrollTo(0,0)}

app.onclick=e=>{
  if(e.target.closest('[data-menu]'))return openMenu();
  const t=e.target.closest('[data-t]');if(t)return openTool(+t.dataset.t);
  const c=e.target.closest('[data-c]');if(c)go('all',c.dataset.c)};
nav.onclick=e=>{const b=e.target.closest('button');if(b)go(b.dataset.s)};
go('home');
